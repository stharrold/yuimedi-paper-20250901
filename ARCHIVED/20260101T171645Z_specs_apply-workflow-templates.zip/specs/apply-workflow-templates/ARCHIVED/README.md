# Archived: specs/apply-workflow-templates

Deprecated specification files are stored here.

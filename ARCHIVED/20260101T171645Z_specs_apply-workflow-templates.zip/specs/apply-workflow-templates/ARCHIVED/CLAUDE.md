---
type: claude-context
directory: specs/apply-workflow-templates/ARCHIVED
purpose: Archived specifications and deprecated files
parent: ../CLAUDE.md
sibling_readme: README.md
children: []
related_skills: []
---

# Claude Code Context: specs/apply-workflow-templates/ARCHIVED

Archived specifications and deprecated files.

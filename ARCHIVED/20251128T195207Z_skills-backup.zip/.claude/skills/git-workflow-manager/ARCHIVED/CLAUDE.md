---
type: claude-context
directory: .claude/skills/git-workflow-manager/ARCHIVED
purpose: Archive of deprecated files from git-workflow-manager
parent: ../CLAUDE.md
sibling_readme: README.md
children: []
related_skills:
  - workflow-utilities
---

# Claude Code Context: Archived Content

## Purpose

Archive of deprecated files from git-workflow-manager

## Directory Structure

[Describe the organization of files in this directory]

## Files in This Directory

[List key files and their purposes]

## Usage

[How to work with code/content in this directory]


## Related Documentation

- **[README.md](README.md)** - Human-readable documentation for this directory
- **[../CLAUDE.md](../CLAUDE.md)** - Parent directory: git-workflow-manager

## Related Skills

- workflow-orchestrator
- workflow-utilities

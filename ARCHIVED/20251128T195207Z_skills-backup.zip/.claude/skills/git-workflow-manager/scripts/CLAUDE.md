---
type: claude-context
directory: .claude/skills/git-workflow-manager/scripts
purpose: Executable Python scripts for this skill.
parent: ../CLAUDE.md
sibling_readme: null
children:
  []
---

# Claude Code Context: scripts

## Purpose

Executable Python scripts for this skill.

## Contents

- `__init__.py` - Python script
- `backmerge_workflow.py` - Python script
- `cleanup_feature.py` - Python script
- `cleanup_release.py` - Python script
- `create_release.py` - Python script
- *...and 4 more items*

## Related

- **Parent**: [git-workflow-manager](../CLAUDE.md)

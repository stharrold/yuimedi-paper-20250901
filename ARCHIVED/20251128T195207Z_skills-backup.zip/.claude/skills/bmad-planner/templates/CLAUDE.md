---
type: claude-context
directory: .claude/skills/bmad-planner/templates
purpose: Markdown and code templates for this skill.
parent: ../CLAUDE.md
sibling_readme: null
children:
  []
---

# Claude Code Context: templates

## Purpose

Markdown and code templates for this skill.

## Contents

*(Empty or contains only hidden files)*

## Related

- **Parent**: [bmad-planner](../CLAUDE.md)

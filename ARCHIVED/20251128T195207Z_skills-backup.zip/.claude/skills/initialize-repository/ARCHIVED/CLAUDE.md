---
type: claude-context
directory: .claude/skills/initialize-repository/ARCHIVED
purpose: Archive of deprecated files from initialize-repository
parent: ../CLAUDE.md
sibling_readme: README.md
children: []
related_skills:
  - workflow-utilities
---

# Claude Code Context: initialize-repository/ARCHIVED

Archived files from initialize-repository skill

## Purpose

This directory contains deprecated files from the initialize-repository skill that have been superseded by newer versions but are preserved for reference.

## Related Documentation

- **[README.md](README.md)** - Human-readable documentation for archived files
- **[../CLAUDE.md](../CLAUDE.md)** - Current initialize-repository context

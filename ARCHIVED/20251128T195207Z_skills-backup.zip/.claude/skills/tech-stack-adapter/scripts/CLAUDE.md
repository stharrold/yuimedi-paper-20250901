---
type: claude-context
directory: .claude/skills/tech-stack-adapter/scripts
purpose: Executable Python scripts for this skill.
parent: ../CLAUDE.md
sibling_readme: null
children:
  []
---

# Claude Code Context: scripts

## Purpose

Executable Python scripts for this skill.

## Contents

- `__init__.py` - Python script
- `detect_stack.py` - Python script

## Related

- **Parent**: [tech-stack-adapter](../CLAUDE.md)

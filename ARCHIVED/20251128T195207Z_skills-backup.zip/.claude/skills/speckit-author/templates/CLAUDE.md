---
type: claude-context
directory: .claude/skills/speckit-author/templates
purpose: Markdown and code templates for this skill.
parent: ../CLAUDE.md
sibling_readme: null
children:
  []
---

# Claude Code Context: templates

## Purpose

Markdown and code templates for this skill.

## Contents

*(Empty or contains only hidden files)*

## Related

- **Parent**: [speckit-author](../CLAUDE.md)

"""AgentDB State Manager skill scripts package."""

__version__ = "1.0.0"

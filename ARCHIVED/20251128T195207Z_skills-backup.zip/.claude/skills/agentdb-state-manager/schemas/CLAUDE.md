---
type: claude-context
directory: .claude/skills/agentdb-state-manager/schemas
purpose: Data schemas and validation definitions.
parent: ../CLAUDE.md
sibling_readme: null
children:
  []
---

# Claude Code Context: schemas

## Purpose

Data schemas and validation definitions.

## Contents

*(Empty or contains only hidden files)*

## Related

- **Parent**: [agentdb-state-manager](../CLAUDE.md)

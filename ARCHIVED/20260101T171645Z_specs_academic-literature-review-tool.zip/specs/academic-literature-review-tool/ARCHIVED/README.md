# Archived: specs/academic-literature-review-tool

Deprecated specification files are stored here.

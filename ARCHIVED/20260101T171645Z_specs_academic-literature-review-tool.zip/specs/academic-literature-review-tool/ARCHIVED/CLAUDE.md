---
type: claude-context
directory: specs/academic-literature-review-tool/ARCHIVED
purpose: Archived specifications for academic-literature-review-tool
parent: ../CLAUDE.md
sibling_readme: null
children: []
related_skills: []
---

# Claude Code Context: specs/academic-literature-review-tool/ARCHIVED

Archived specifications and deprecated files.

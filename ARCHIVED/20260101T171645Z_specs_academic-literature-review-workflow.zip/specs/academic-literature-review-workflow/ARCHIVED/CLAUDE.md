---
type: claude-context
directory: specs/academic-literature-review-workflow/ARCHIVED
purpose: Archived specifications and deprecated files
parent: ../CLAUDE.md
---

# Claude Code Context: specs/academic-literature-review-workflow/ARCHIVED

Archived specifications and deprecated files.

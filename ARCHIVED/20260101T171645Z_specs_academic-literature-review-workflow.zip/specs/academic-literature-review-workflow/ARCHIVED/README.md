# Archived: specs/academic-literature-review-workflow

Deprecated specification files are stored here.

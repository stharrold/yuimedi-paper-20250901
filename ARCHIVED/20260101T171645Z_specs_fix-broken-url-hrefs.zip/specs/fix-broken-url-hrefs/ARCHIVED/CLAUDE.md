---
type: claude-context
directory: specs/fix-broken-url-hrefs/ARCHIVED
purpose: Archived specifications and deprecated files
parent: specs/fix-broken-url-hrefs/CLAUDE.md
sibling_readme: null
children: []
related_skills: []
---

# Claude Code Context: specs/fix-broken-url-hrefs/ARCHIVED

Archived specifications and deprecated files.

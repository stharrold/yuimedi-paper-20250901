---
type: claude-context
directory: planning/reference-validation/ARCHIVED
purpose: Archive of deprecated planning documents
parent: ../CLAUDE.md
sibling_readme: README.md
children: []
related_skills: []
---

# Claude Code Context: Archived Planning

## Purpose

Archive of deprecated planning documents from reference-validation

## Usage

This directory contains previous versions of planning documents that have been superseded or are no longer relevant.

## Related Documentation

- **[README.md](README.md)** - Archive information

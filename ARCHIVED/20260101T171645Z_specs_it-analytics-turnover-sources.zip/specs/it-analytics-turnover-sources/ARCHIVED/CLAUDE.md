---
type: claude-context
directory: specs/it-analytics-turnover-sources/ARCHIVED
purpose: Archived specifications for it-analytics-turnover-sources feature
parent: ../CLAUDE.md
sibling_readme: README.md
---

# Claude Code Context: specs/it-analytics-turnover-sources/ARCHIVED

Archived specifications and deprecated files.

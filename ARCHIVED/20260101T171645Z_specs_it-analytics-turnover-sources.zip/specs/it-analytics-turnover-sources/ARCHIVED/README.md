# Archived: specs/it-analytics-turnover-sources

Deprecated specification files are stored here.

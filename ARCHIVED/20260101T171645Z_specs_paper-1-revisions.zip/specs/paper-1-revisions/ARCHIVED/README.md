# Archived: specs/paper-1-revisions

Deprecated specification files are stored here.

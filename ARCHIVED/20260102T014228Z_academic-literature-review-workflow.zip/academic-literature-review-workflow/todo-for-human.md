# TODO for Human

## Prerequisites Setup

### 1. Environment
- [ ] Install Docker Desktop
- [ ] Install `uv` package manager: `curl -LsSf https://astral.sh/uv/install.sh | sh`
- [ ] Install GitHub CLI: `brew install gh` (or appropriate for your OS)
- [ ] Install Git and configure user: `git config --global user.name "Your Name"`

### 2. Accounts & Credentials
- [ ] GitHub account with repository created
- [ ] Docker Hub account
- [ ] Zenodo account (link to GitHub)
- [ ] API keys for:
  - [ ] Crossref (register email)
  - [ ] PubMed (optional)
  - [ ] Semantic Scholar (optional)
  - [ ] Anthropic (for AI features)

### 3. Repository Setup
- [ ] Fork/clone repository
- [ ] Set up branch protection rules:
  - `main`: 2 reviewers, dismiss stale reviews
  - `develop`: 1 reviewer, require tests
- [ ] Add secrets to GitHub repository:
  ```
  DOCKER_USERNAME
  DOCKER_TOKEN
  ZENODO_TOKEN
  ZENODO_DEPOSITION_ID
  CROSSREF_EMAIL
  PUBMED_API_KEY
  ANTHROPIC_API_KEY
  ```

## Configuration

### 4. Local Environment
- [ ] Copy `.env.example` to `.env`
- [ ] Fill in all API keys in `.env`
- [ ] Update author information in:
  - [ ] `pyproject.toml`
  - [ ] `.zenodo.json`
  - [ ] `CITATION.cff`
  - [ ] `README.md`

### 5. Docker Hub
- [ ] Create repository: `yourusername/academic-review`
- [ ] Generate access token for GitHub Actions
- [ ] Test login: `docker login`

### 6. Zenodo
- [ ] Enable GitHub integration
- [ ] Create new deposition
- [ ] Copy deposition ID to GitHub secrets
- [ ] Reserve DOI

## Testing & Validation

### 7. Local Testing
- [ ] Run `make setup`
- [ ] Activate venv: `source .venv/bin/activate`
- [ ] Run `make test`
- [ ] Run `make docker-build`
- [ ] Run `docker-compose run --rm dev`

### 8. Workflow Testing
- [ ] Initialize review: `make init`
- [ ] Test search: `make search KEYWORDS="test"`
- [ ] Verify data persistence
- [ ] Test export formats

### 9. CI/CD Testing
- [ ] Create feature branch: `git checkout -b initials/test`
- [ ] Make change and push
- [ ] Create PR to develop
- [ ] Verify GitHub Actions run
- [ ] Merge and check develop→main flow

## Documentation

### 10. Project Documentation
- [ ] Update README with your project details
- [ ] Add example workflow to docs/
- [ ] Create tutorial video/screenshots
- [ ] Write blog post about the tool

### 11. Academic Integration
- [ ] Update institutional affiliation
- [ ] Add grant acknowledgments
- [ ] Link to research group page
- [ ] Submit software paper

## Maintenance

### 12. Regular Tasks
- [ ] Weekly: Run `make backup`
- [ ] Monthly: Update dependencies
- [ ] Quarterly: Review security alerts
- [ ] Yearly: Renew API keys

### 13. Community
- [ ] Create GitHub discussions
- [ ] Set up issue templates
- [ ] Write contributing guidelines
- [ ] Plan first release

## Checklist Before First Release

- [ ] All tests passing
- [ ] Documentation complete
- [ ] Docker image builds
- [ ] Zenodo DOI reserved
- [ ] Security scan clean
- [ ] License confirmed
- [ ] Citation ready

---

**Note**: Items marked with [ ] require manual completion before the system is production-ready.
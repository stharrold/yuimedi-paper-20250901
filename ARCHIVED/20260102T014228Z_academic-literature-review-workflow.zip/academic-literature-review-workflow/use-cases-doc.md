# Complete Use Cases Documentation

## Overview

This document describes all use cases for the Academic Literature Review Tool with required dependencies.

## Dependencies

All dependencies are managed via `pyproject.toml`:

```toml
# Core
click           # CLI framework
requests        # HTTP client
httpx           # Async HTTP
python-dotenv   # Environment management
pydantic        # Data validation

# Academic
bibtexparser    # BibTeX parsing
biopython       # PubMed API
crossref-commons # Crossref API (auto-installed)

# Analysis
numpy           # Numerical computing
scikit-learn    # Theme clustering
anthropic       # AI analysis (optional)

# Export
python-docx     # Word documents
jinja2          # LaTeX templates
markdown        # Markdown processing
weasyprint      # HTML to PDF (optional)

# UI
rich            # Terminal formatting
```

## Use Case 1: Initialize Review

**Purpose**: Start new systematic review project

```bash
make init
# or
academic-review init
```

**Workflow**:
1. Prompt for review metadata
2. Create review structure
3. Initialize git repository
4. Set up review database

**Files Created**:
- `review_data/current_review.json`
- `review_data/config.json`

## Use Case 2: Literature Search

**Purpose**: Search multiple databases for papers

```bash
make search KEYWORDS="machine learning,healthcare" DB=all
```

**Workflow**:
1. Parse search query
2. Execute parallel searches:
   - Crossref (no API key required)
   - PubMed (optional API key)
   - ArXiv (no API key required)
   - Semantic Scholar (optional API key)
3. Deduplicate by DOI
4. Save results

**Features**:
- Automatic retry on failure
- Progress indicators
- Export search log

## Use Case 3: Paper Assessment

**Purpose**: Quality assessment and screening

```bash
make assess 10.1234/example.doi
```

**Workflow**:
1. Display paper details
2. Quality scoring (0-10)
3. Inclusion/exclusion decision
4. Save assessment

**Batch Mode**:
```bash
make assess-batch assessments.csv
```

## Use Case 4: Thematic Analysis

**Purpose**: Extract themes from included papers

```bash
make analyze
```

**Methods**:
1. **Keyword-based** (default):
   - TF-IDF extraction
   - Co-occurrence matrix
   - Hierarchical clustering

2. **AI-powered** (if API key):
   - Claude/GPT analysis
   - Semantic understanding
   - Research gap identification

**Output**:
- Theme hierarchy
- Concept map
- Gap analysis

## Use Case 5: Synthesis Generation

**Purpose**: Create narrative synthesis

```bash
make synthesize
```

**Sections Generated**:
1. Introduction with research question
2. Methodology summary
3. Theme-based findings
4. Evidence tables
5. Research gaps
6. Conclusions

**Formats**:
- Markdown (primary)
- Can export to others

## Use Case 6: Export Formats

**Purpose**: Generate publication-ready outputs

```bash
make export FORMAT=latex JOURNAL=nature
```

**Supported Formats**:

### BibTeX
```bash
make export FORMAT=bibtex
```
- All references
- Ready for LaTeX

### LaTeX
```bash
make export FORMAT=latex
```
Templates:
- `generic` (default)
- `nature`
- `ieee`
- `apa7`

### Word/DOCX
```bash
make export FORMAT=docx
```
- APA formatting
- Track changes ready
- Citation management

### HTML
```bash
make export FORMAT=html
```
- Interactive dashboard
- Search functionality
- D3.js visualizations
- Mobile responsive

### JSON
```bash
make export FORMAT=json
```
- Complete data export
- Machine readable
- Backup format

## Use Case 7: Collaboration

**Purpose**: Multi-author workflow

```bash
# Share review
make share EMAIL=collaborator@example.com

# Sync changes
make sync

# Merge conflicts
make merge-review
```

## Use Case 8: Quality Control

**Purpose**: Ensure review quality

```bash
make qcheck
```

**Checks**:
- Duplicate papers
- Missing assessments
- Incomplete data
- Statistical validity

## Use Case 9: PRISMA Compliance

**Purpose**: Generate PRISMA flow diagram

```bash
make prisma
```

**Output**:
- SVG diagram
- Markdown report
- Compliance checklist

## Use Case 10: Citation Network

**Purpose**: Analyze citation relationships

```bash
make network
```

**Features**:
- Forward/backward citations
- Influential papers
- Research clusters
- Interactive graph

## Environment Variables

Required in `.env`:
```bash
# Required
CROSSREF_EMAIL=your-email@example.com

# Optional but recommended
PUBMED_API_KEY=your-key
SEMANTIC_SCHOLAR_API_KEY=your-key
ANTHROPIC_API_KEY=your-key
OPENAI_API_KEY=your-key

# Performance
MAX_WORKERS=4
CACHE_DIR=./cache
REQUEST_TIMEOUT=30
```

## Docker Usage

All use cases work in Docker:

```bash
# Development
docker-compose run --rm dev make search

# Production
docker run -it --rm \
  -e CROSSREF_EMAIL="$CROSSREF_EMAIL" \
  -v $(pwd)/review_data:/opt/data/my-repo/review_data \
  yourdockerhub/academic-review:latest \
  academic-review search --keywords="your terms"
```

## Troubleshooting

### Missing Dependencies
```bash
uv pip install -e ".[dev,ai,web]"
```

### API Rate Limits
- Crossref: 50/sec (with email)
- PubMed: 3/sec
- Auto-retry with backoff

### Memory Issues
- Process in batches
- Use `--limit` flag
- Increase Docker memory

## Performance Benchmarks

- Search: ~1000 papers/minute
- Deduplication: O(n log n)
- Theme analysis: ~30 seconds for 500 papers
- Export: <5 seconds any format
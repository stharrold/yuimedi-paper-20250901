# Testing Requirements

## Test-Driven Development Cycle

### 1. RED Phase
```
Write test FIRST -> Run -> Verify failure
Test must fail for the right reason
```

### 2. GREEN Phase  
```
Minimal code to pass -> Run -> Verify success
No premature optimization
```

### 3. REFACTOR Phase
```
Improve code -> Run -> Maintain green
Extract patterns -> Run -> Still green
```

## Coverage Requirements

### Minimum Thresholds
```json
{
  "overall": 80,
  "statements": 80,
  "branches": 75,
  "functions": 80,
  "lines": 80,
  "critical_paths": 100
}
```

## Test Categories

### Unit Tests (MUST have)
- Pure functions: all code paths
- Edge cases: null, empty, boundary
- Error conditions: invalid inputs
- Performance: execution time limits

### Integration Tests (MUST have)
- API endpoints: all routes
- Database operations: CRUD + transactions  
- External services: with mocks
- Authentication flows: all paths

### E2E Tests (SHOULD have)
- Critical user journeys
- Payment/transaction flows
- Multi-step workflows
- Cross-browser when relevant

## Test Quality Indicators

### Good Test Characteristics
- **Fast**: <100ms per unit test
- **Isolated**: No dependencies between tests
- **Repeatable**: Same result every run
- **Self-validating**: Clear pass/fail
- **Timely**: Written with/before code

## Test Naming Convention
```
test_<unit>_<scenario>_<expected_outcome>

Examples:
test_calculateTotal_withDiscount_returnsDiscountedPrice()
test_userLogin_invalidCredentials_throwsAuthError()
test_dataProcessor_emptyInput_returnsEmptyArray()
```

## Mocking Strategy

### What to Mock
- External services
- Database calls
- File system operations
- Time-dependent functions
- Random number generators

### What NOT to Mock
- Pure functions
- Data transformations
- Business logic
- Value objects
- Simple calculations

## Performance Testing

### Benchmarks Required For
- Algorithms with O(n^2) or worse
- Database queries
- API response times
- Memory-intensive operations
- Concurrent operations

### Performance Assertions
```javascript
expect(executionTime).toBeLessThan(100); // ms
expect(memoryUsage).toBeLessThan(50); // MB
expect(queryTime).toBeLessThan(200); // ms
```

## Test Data Management

### Fixtures
- Minimal but complete
- Representative of production
- Version controlled
- Reset between tests

### Factories
```python
def user_factory(**overrides):
    defaults = {
        "name": "Test User",
        "email": "test@example.com",
        "role": "user"
    }
    return {**defaults, **overrides}
```

## Continuous Testing

### On Every Change
- Run affected unit tests
- Check coverage delta
- Validate test quality

### Before Commit
- Full test suite
- Coverage report
- Performance benchmarks
- Security scans
# Secrets Management via Environment Variables

## Local Development

Create `.env` (gitignored, not mounted):
```bash
# Database API Keys
CROSSREF_EMAIL=your-email@example.com
PUBMED_API_KEY=your-pubmed-key
SEMANTIC_SCHOLAR_API_KEY=your-s2-key

# AI Services
ANTHROPIC_API_KEY=your-anthropic-key
OPENAI_API_KEY=your-openai-key

# Production Database
DATABASE_URL=postgresql://user:pass@host/db
```

Run with:
```bash
# Docker Compose reads .env automatically
docker-compose run --rm dev

# Or explicitly:
docker-compose --env-file .env run --rm dev
```

## Application Code

Update config to read from environment:
```python
# config/settings.py
import os
from typing import Optional

class Settings:
    # API Keys
    crossref_email: str = os.environ.get('CROSSREF_EMAIL', '')
    pubmed_api_key: Optional[str] = os.environ.get('PUBMED_API_KEY')
    semantic_scholar_api_key: Optional[str] = os.environ.get('SEMANTIC_SCHOLAR_API_KEY')
    anthropic_api_key: Optional[str] = os.environ.get('ANTHROPIC_API_KEY')
    
    # Validate required secrets
    def validate(self):
        if not self.crossref_email:
            raise ValueError("CROSSREF_EMAIL required")

settings = Settings()
```

## GitHub Actions

Set secrets in repository settings, then:
```yaml
# .github/workflows/ci.yml
- name: Run tests with secrets
  run: |
    docker run --rm \
      -e CROSSREF_EMAIL=${{ secrets.CROSSREF_EMAIL }} \
      -e PUBMED_API_KEY=${{ secrets.PUBMED_API_KEY }} \
      -e ANTHROPIC_API_KEY=${{ secrets.ANTHROPIC_API_KEY }} \
      academic-review:test pytest
```

## Production Deployment

```bash
# Run with secrets
docker run -it --rm \
  -e CROSSREF_EMAIL="$CROSSREF_EMAIL" \
  -e PUBMED_API_KEY="$PUBMED_API_KEY" \
  -e ANTHROPIC_API_KEY="$ANTHROPIC_API_KEY" \
  -v review_data:/opt/data/my-repo/review_data \
  your-dockerhub/academic-review:latest
```

## Security Best Practices

1. **Never commit `.env` files**
2. **Use least privilege** - only pass needed secrets
3. **Rotate keys regularly**
4. **Use secret management services** in production (AWS Secrets Manager, Vault)

## .gitignore

```
.env
.env.*
!.env.example
secrets/
```
# Claude Code Implementation Instructions

## Project: Academic Literature Review Tool

You will implement a test-driven systematic literature review workflow system following the instructions in `TODO_FOR_AI.json`. This is a production-grade CLI tool for managing academic research.

## Implementation Requirements

1. **Follow TDD strictly**: Write tests BEFORE implementation for each component
2. **Apply SOLID principles**: Single responsibility, dependency injection, clean architecture
3. **Handle all edge cases**: Validate inputs, catch exceptions, provide meaningful errors
4. **Maintain code quality**: <10 cyclomatic complexity, >80% test coverage

## Phase-by-Phase Instructions

### Setup Phase
1. Read `TODO_FOR_AI.json` completely before starting
2. Create the project structure exactly as specified
3. Copy all configuration files from the referenced artifacts
4. Set executable permissions on scripts: `chmod +x scripts/sync.sh .git/hooks/pre-push`

### Implementation Phase
For each phase in TODO_FOR_AI.json:
1. Complete tasks in order
2. When "Copy from artifact X" is mentioned, find the artifact named X in this conversation
3. Run tests after each implementation: `pytest tests/path/to/test.py -xvs`
4. Commit after each working component

### Testing Protocol
- After implementing each file, run its specific tests
- Fix any failures before proceeding
- Run full test suite after each phase: `pytest --cov=.`
- Ensure coverage never drops below 80%

### Docker Validation
After Phase 5:
```bash
docker-compose build
docker-compose run --rm dev
# Inside container:
make init
make search
make status
```

### Quality Checks
Before completing each phase:
- Run linter: `flake8 .`
- Check types: `mypy domain/ application/`
- Format code: `black . --line-length=88`

## Critical Implementation Details

### Paper Entity
- Immutable DOI value objects
- Validation in __post_init__
- Equality based on DOI only

### Review Entity
- Enforce workflow stages (no skipping)
- Papers stored as Set to prevent duplicates
- Stage transitions are one-way only

### CLI Interface
- All commands must handle missing review gracefully
- Progress indicators for long operations
- Clear error messages for users

### Search Adapters
- Implement exponential backoff for rate limits
- Parse incomplete data gracefully (missing authors, etc.)
- Return empty list on API failures (don't crash)

### Persistence
- Atomic writes (write to temp, then rename)
- Backup before overwrites
- Handle concurrent access

## Validation Checklist

After full implementation:
- [ ] All 7 phases complete
- [ ] `pytest` shows 100% passing tests
- [ ] Coverage >= 80%
- [ ] Docker image builds successfully
- [ ] Can complete full review workflow:
  ```bash
  make init
  make search KEYWORDS="machine learning"
  make assess <doi>
  make analyze
  make synthesize
  make export
  ```

## Common Pitfalls to Avoid

1. Don't skip tests - TDD means test FIRST
2. Don't use mutable default arguments
3. Don't catch generic Exception - be specific
4. Don't hardcode paths - use pathlib
5. Don't forget to handle empty/null cases

## When Stuck

1. Check the original artifacts in this conversation
2. Ensure dependencies are installed: `uv pip install -e ".[dev]"`
3. Verify you're in the virtual environment
4. Check TODO_FOR_AI.json for exact requirements

Start with Phase 1 and proceed systematically. Each phase builds on the previous one.
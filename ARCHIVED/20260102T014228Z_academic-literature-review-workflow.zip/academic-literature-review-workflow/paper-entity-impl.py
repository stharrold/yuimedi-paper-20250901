# domain/entities/paper.py
from typing import List, Optional, Dict, Any
from datetime import datetime
from dataclasses import dataclass, field

from domain.values.doi import DOI
from domain.values.author import Author
from domain.exceptions import ValidationError


@dataclass
class Paper:
    """
    Paper entity representing an academic publication.
    
    This is the core entity for literature review management.
    Follows DDD principles with validation and business logic.
    """
    doi: DOI
    title: str
    authors: List[Author]
    publication_year: int
    journal: str
    abstract: str = ""
    keywords: List[str] = field(default_factory=list)
    quality_score: Optional[float] = None
    
    def __post_init__(self):
        """Validate paper data on creation"""
        self._validate_title()
        self._validate_authors()
        self._validate_publication_year()
        
    def _validate_title(self) -> None:
        """Ensure title is not empty"""
        if not self.title or not self.title.strip():
            raise ValidationError("Title cannot be empty")
            
    def _validate_authors(self) -> None:
        """Ensure at least one author exists"""
        if not self.authors:
            raise ValidationError("At least one author required")
            
    def _validate_publication_year(self) -> None:
        """Ensure publication year is valid"""
        current_year = datetime.now().year
        if self.publication_year > current_year:
            raise ValidationError(
                f"Invalid publication year: {self.publication_year} is in the future"
            )
        if self.publication_year < 1900:
            raise ValidationError(
                f"Invalid publication year: {self.publication_year} is too old"
            )
            
    def __eq__(self, other) -> bool:
        """Papers are equal if DOIs match"""
        if not isinstance(other, Paper):
            return False
        return self.doi == other.doi
        
    def __hash__(self) -> int:
        """Hash based on DOI for set/dict usage"""
        return hash(self.doi)
        
    def add_keywords(self, keywords: List[str]) -> None:
        """
        Add keywords, automatically removing duplicates.
        
        Args:
            keywords: List of keyword strings
        """
        # Convert to set and back to remove duplicates
        unique_keywords = list(dict.fromkeys(keywords))
        self.keywords = unique_keywords
        
    def set_quality_score(self, score: float) -> None:
        """
        Set paper quality score (0-10 scale).
        
        Args:
            score: Quality score between 0 and 10
            
        Raises:
            ValidationError: If score is out of valid range
        """
        if not 0 <= score <= 10:
            raise ValidationError("Quality score must be between 0 and 10")
        self.quality_score = score
        
    def get_citation_key(self) -> str:
        """
        Generate citation key in format: AuthorYear or AuthorEtAlYear.
        
        Returns:
            Citation key string
        """
        if len(self.authors) == 1:
            return f"{self.authors[0].last_name}{self.publication_year}"
        elif len(self.authors) == 2:
            return f"{self.authors[0].last_name}{self.publication_year}"
        else:
            return f"{self.authors[0].last_name}EtAl{self.publication_year}"
            
    def is_relevant_to(self, search_terms: List[str]) -> bool:
        """
        Check if paper is relevant to given search terms.
        
        Searches in title, abstract, and keywords.
        
        Args:
            search_terms: List of terms to search for
            
        Returns:
            True if any search term is found
        """
        # Convert to lowercase for case-insensitive search
        search_targets = (
            self.title.lower() + " " + 
            self.abstract.lower() + " " +
            " ".join(self.keywords).lower()
        )
        
        return any(
            term.lower() in search_targets 
            for term in search_terms
        )
        
    def to_dict(self) -> Dict[str, Any]:
        """
        Convert paper to dictionary for serialization.
        
        Returns:
            Dictionary representation of paper
        """
        return {
            "doi": str(self.doi),
            "title": self.title,
            "authors": [author.to_dict() for author in self.authors],
            "publication_year": self.publication_year,
            "journal": self.journal,
            "abstract": self.abstract,
            "keywords": self.keywords,
            "quality_score": self.quality_score
        }
        
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Paper':
        """
        Create Paper instance from dictionary.
        
        Args:
            data: Dictionary with paper data
            
        Returns:
            Paper instance
        """
        return cls(
            doi=DOI(data["doi"]),
            title=data["title"],
            authors=[Author.from_dict(a) for a in data["authors"]],
            publication_year=data["publication_year"],
            journal=data["journal"],
            abstract=data.get("abstract", ""),
            keywords=data.get("keywords", []),
            quality_score=data.get("quality_score")
        )


# domain/exceptions.py
class ValidationError(Exception):
    """Domain validation error"""
    pass


# domain/values/doi.py
import re
from dataclasses import dataclass


@dataclass(frozen=True)
class DOI:
    """
    DOI (Digital Object Identifier) value object.
    
    Ensures DOI format validity and provides consistent representation.
    """
    value: str
    
    def __post_init__(self):
        """Validate DOI format"""
        # Simple DOI pattern - can be enhanced
        pattern = r'^10\.\d{4,}/[-._;()/:\w]+$'
        if not re.match(pattern, self.value):
            raise ValidationError(f"Invalid DOI format: {self.value}")
            
    def __str__(self) -> str:
        """String representation is the DOI value"""
        return self.value
        
    def to_url(self) -> str:
        """Convert to DOI resolver URL"""
        return f"https://doi.org/{self.value}"


# domain/values/author.py
from dataclasses import dataclass
from typing import Optional, Dict, Any


@dataclass(frozen=True)
class Author:
    """
    Author value object representing paper authors.
    
    Immutable to ensure consistency.
    """
    last_name: str
    first_name: str
    initials: str
    orcid: Optional[str] = None
    
    def __post_init__(self):
        """Validate author data"""
        if not self.last_name:
            raise ValidationError("Author last name required")
        if not self.first_name:
            raise ValidationError("Author first name required")
            
    def __str__(self) -> str:
        """Format as 'Last, First'"""
        return f"{self.last_name}, {self.first_name}"
        
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "last_name": self.last_name,
            "first_name": self.first_name,
            "initials": self.initials,
            "orcid": self.orcid
        }
        
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Author':
        """Create from dictionary"""
        return cls(
            last_name=data["last_name"],
            first_name=data["first_name"],
            initials=data["initials"],
            orcid=data.get("orcid")
        )
# Coding Standards

## SOLID Principles Application

### Single Responsibility
- One reason to change per class/function
- Extract complex logic into focused helpers
- Document the single purpose explicitly

### Open/Closed
- Extend through composition, not modification
- Use interfaces/protocols for extensibility
- Configuration over code changes

### Liskov Substitution
- Derived types fully replaceable
- No strengthened preconditions
- No weakened postconditions

### Interface Segregation
- Small, focused interfaces
- Client-specific contracts
- Avoid fat interfaces

### Dependency Inversion
- Depend on abstractions
- Inject dependencies
- Mock boundaries for testing

## Code Quality Metrics

### Complexity Thresholds
```json
{
  "cyclomatic_complexity": 10,
  "cognitive_complexity": 15,
  "max_function_lines": 50,
  "max_file_lines": 300,
  "max_parameters": 4
}
```

## Naming Conventions

### Variables
- Descriptive, not clever
- Boolean: is/has/can prefix
- Collections: plural nouns
- Constants: UPPER_SNAKE_CASE

### Functions
- Verb phrases for actions
- Noun phrases for accessors
- Question form for predicates
- Async suffix for promises

## Error Handling

### Pattern
```python
try:
    # Operation with clear scope
    result = risky_operation()
except SpecificException as e:
    # Log with context
    logger.error(f"Operation failed: {e}", extra={"context": context})
    # Recover or propagate
    raise DomainException("User-friendly message") from e
finally:
    # Cleanup guaranteed
    cleanup_resources()
```

## Documentation Requirements

### Function Documentation
- Purpose (what, not how)
- Parameters with types
- Return value description
- Exceptions that can be raised
- Example usage for complex cases

### Inline Comments
- Why, not what
- Explain business logic
- Flag workarounds with ticket refs
- Mark optimization opportunities
# tests/domain/entities/test_paper.py
import pytest
from datetime import datetime
from domain.entities.paper import Paper
from domain.values.doi import DOI
from domain.values.author import Author
from domain.exceptions import ValidationError


class TestPaperEntity:
    """Test suite for Paper entity following TDD principles"""
    
    def test_paper_creation_with_valid_data(self):
        """test_paper_creation_validData_returnsValidPaper"""
        # Arrange
        doi = DOI("10.1234/example.doi")
        authors = [Author("Smith", "John", "J")]
        
        # Act
        paper = Paper(
            doi=doi,
            title="Example Paper Title",
            authors=authors,
            publication_year=2023,
            journal="Nature",
            abstract="This is an abstract"
        )
        
        # Assert
        assert paper.doi == doi
        assert paper.title == "Example Paper Title"
        assert len(paper.authors) == 1
        assert paper.publication_year == 2023
        assert paper.quality_score is None
        
    def test_paper_creation_withEmptyTitle_throwsValidationError(self):
        """test_paper_creation_emptyTitle_throwsValidationError"""
        # Arrange
        doi = DOI("10.1234/example.doi")
        authors = [Author("Smith", "John", "J")]
        
        # Act & Assert
        with pytest.raises(ValidationError) as exc:
            Paper(
                doi=doi,
                title="",
                authors=authors,
                publication_year=2023,
                journal="Nature"
            )
        assert "Title cannot be empty" in str(exc.value)
        
    def test_paper_creation_withNoAuthors_throwsValidationError(self):
        """test_paper_creation_noAuthors_throwsValidationError"""
        # Arrange
        doi = DOI("10.1234/example.doi")
        
        # Act & Assert
        with pytest.raises(ValidationError) as exc:
            Paper(
                doi=doi,
                title="Valid Title",
                authors=[],
                publication_year=2023,
                journal="Nature"
            )
        assert "At least one author required" in str(exc.value)
        
    def test_paper_creation_withInvalidYear_throwsValidationError(self):
        """test_paper_creation_futureYear_throwsValidationError"""
        # Arrange
        doi = DOI("10.1234/example.doi")
        authors = [Author("Smith", "John", "J")]
        future_year = datetime.now().year + 1
        
        # Act & Assert
        with pytest.raises(ValidationError) as exc:
            Paper(
                doi=doi,
                title="Valid Title",
                authors=authors,
                publication_year=future_year,
                journal="Nature"
            )
        assert "Invalid publication year" in str(exc.value)
        
    def test_paper_equality_sameDOI_returnsTrue(self):
        """test_paper_equality_sameDOI_returnsTrue"""
        # Arrange
        doi = DOI("10.1234/example.doi")
        authors = [Author("Smith", "John", "J")]
        
        paper1 = Paper(
            doi=doi,
            title="Title 1",
            authors=authors,
            publication_year=2023,
            journal="Nature"
        )
        
        paper2 = Paper(
            doi=doi,
            title="Title 2",  # Different title
            authors=authors,
            publication_year=2022,  # Different year
            journal="Science"  # Different journal
        )
        
        # Act & Assert
        assert paper1 == paper2  # Papers are equal if DOIs match
        
    def test_paper_addKeywords_validKeywords_addsSuccessfully(self):
        """test_paper_addKeywords_validInput_updatesKeywordsList"""
        # Arrange
        paper = self._create_valid_paper()
        keywords = ["machine learning", "deep learning", "AI"]
        
        # Act
        paper.add_keywords(keywords)
        
        # Assert
        assert len(paper.keywords) == 3
        assert "machine learning" in paper.keywords
        assert paper.keywords == keywords
        
    def test_paper_addKeywords_duplicates_removedAutomatically(self):
        """test_paper_addKeywords_duplicates_stortsUniqueOnly"""
        # Arrange
        paper = self._create_valid_paper()
        
        # Act
        paper.add_keywords(["ML", "AI", "ML"])
        
        # Assert
        assert len(paper.keywords) == 2
        assert paper.keywords == ["ML", "AI"]
        
    def test_paper_setQualityScore_validScore_updatesSuccessfully(self):
        """test_paper_setQualityScore_validRange_acceptsScore"""
        # Arrange
        paper = self._create_valid_paper()
        
        # Act
        paper.set_quality_score(8.5)
        
        # Assert
        assert paper.quality_score == 8.5
        
    def test_paper_setQualityScore_outOfRange_throwsValidationError(self):
        """test_paper_setQualityScore_aboveMax_throwsValidationError"""
        # Arrange
        paper = self._create_valid_paper()
        
        # Act & Assert
        with pytest.raises(ValidationError) as exc:
            paper.set_quality_score(10.5)
        assert "Quality score must be between 0 and 10" in str(exc.value)
        
    def test_paper_citationKey_generation_returnsExpectedFormat(self):
        """test_paper_citationKey_standardFormat_returnsAuthorYear"""
        # Arrange
        paper = self._create_valid_paper()
        
        # Act
        citation_key = paper.get_citation_key()
        
        # Assert
        assert citation_key == "Smith2023"
        
    def test_paper_citationKey_multipleAuthors_returnsFirstAuthorEtAl(self):
        """test_paper_citationKey_multipleAuthors_returnsEtAlFormat"""
        # Arrange
        authors = [
            Author("Smith", "John", "J"),
            Author("Doe", "Jane", "J"),
            Author("Brown", "Bob", "B")
        ]
        paper = Paper(
            doi=DOI("10.1234/example.doi"),
            title="Multi-author paper",
            authors=authors,
            publication_year=2023,
            journal="Nature"
        )
        
        # Act
        citation_key = paper.get_citation_key()
        
        # Assert
        assert citation_key == "SmithEtAl2023"
        
    def test_paper_isRelevant_matchingKeywords_returnsTrue(self):
        """test_paper_isRelevant_keywordMatch_identifiesRelevance"""
        # Arrange
        paper = self._create_valid_paper()
        paper.add_keywords(["machine learning", "neural networks"])
        search_terms = ["learning", "AI"]
        
        # Act
        is_relevant = paper.is_relevant_to(search_terms)
        
        # Assert
        assert is_relevant is True
        
    def test_paper_toDict_allFields_returnsCompleteDict(self):
        """test_paper_toDict_completeData_serializesAllFields"""
        # Arrange
        paper = self._create_valid_paper()
        paper.add_keywords(["test", "TDD"])
        paper.set_quality_score(9.0)
        
        # Act
        paper_dict = paper.to_dict()
        
        # Assert
        assert paper_dict["doi"] == "10.1234/example.doi"
        assert paper_dict["title"] == "Test Paper"
        assert len(paper_dict["authors"]) == 1
        assert paper_dict["publication_year"] == 2023
        assert paper_dict["journal"] == "Nature"
        assert paper_dict["keywords"] == ["test", "TDD"]
        assert paper_dict["quality_score"] == 9.0
        
    # Helper methods
    def _create_valid_paper(self) -> Paper:
        """Factory method for creating valid test papers"""
        return Paper(
            doi=DOI("10.1234/example.doi"),
            title="Test Paper",
            authors=[Author("Smith", "John", "J")],
            publication_year=2023,
            journal="Nature",
            abstract="Test abstract"
        )


class TestPaperPerformance:
    """Performance tests for Paper entity"""
    
    def test_paper_creation_performance(self, benchmark):
        """test_paper_creation_under100ms_meetsPerformanceTarget"""
        # Arrange
        doi = DOI("10.1234/example.doi")
        authors = [Author(f"Author{i}", f"Name{i}", "A") for i in range(10)]
        
        # Act & Assert
        result = benchmark(
            Paper,
            doi=doi,
            title="Performance Test Paper",
            authors=authors,
            publication_year=2023,
            journal="Nature"
        )
        
        assert result.title == "Performance Test Paper"
        # Benchmark automatically fails if >100ms (configured in pytest.ini)
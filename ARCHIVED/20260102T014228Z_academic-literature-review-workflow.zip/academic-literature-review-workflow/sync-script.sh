#!/bin/bash
# scripts/sync.sh - Keep feature branches synced with develop

set -e

# Colors
YELLOW='\033[1;33m'
GREEN='\033[1;32m'
RED='\033[1;31m'
NC='\033[0m'

# Get current branch
BRANCH=$(git rev-parse --abbrev-ref HEAD)

# Verify branch format
if [[ ! "$BRANCH" =~ ^[a-z]{2,3}/ ]]; then
    echo -e "${RED}Error: Must be on an initials/feature branch${NC}"
    exit 1
fi

echo -e "${YELLOW}Syncing $BRANCH with develop...${NC}"

# Stash any uncommitted changes
if [[ -n $(git status -s) ]]; then
    echo "Stashing uncommitted changes..."
    git stash push -m "sync-$(date +%s)"
    STASHED=true
fi

# Fetch and rebase
git fetch origin
git rebase origin/develop

# Run tests
echo -e "${YELLOW}Running tests...${NC}"
make test

# Restore stashed changes
if [[ "$STASHED" == "true" ]]; then
    echo "Restoring stashed changes..."
    git stash pop
fi

echo -e "${GREEN}✓ Branch synced successfully!${NC}"
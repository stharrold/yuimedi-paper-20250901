# tests/domain/entities/test_review.py
import pytest
from datetime import datetime
from domain.entities.review import Review, ReviewStage
from domain.entities.paper import Paper
from domain.values.doi import DOI
from domain.values.author import Author
from domain.exceptions import ValidationError, WorkflowError


class TestReviewEntity:
    """Test suite for Literature Review entity"""
    
    def test_review_creation_withValidData_returnsReview(self):
        """test_review_creation_validInput_createsSuccessfully"""
        # Arrange
        research_question = "What are the impacts of AI on healthcare?"
        
        # Act
        review = Review(
            title="AI in Healthcare: A Systematic Review",
            research_question=research_question,
            inclusion_criteria=["peer-reviewed", "2020-2024"],
            exclusion_criteria=["preprints"]
        )
        
        # Assert
        assert review.title == "AI in Healthcare: A Systematic Review"
        assert review.research_question == research_question
        assert review.stage == ReviewStage.PLANNING
        assert len(review.papers) == 0
        assert review.created_at is not None
        
    def test_review_creation_withEmptyTitle_throwsValidationError(self):
        """test_review_creation_emptyTitle_throwsValidationError"""
        # Act & Assert
        with pytest.raises(ValidationError) as exc:
            Review(
                title="",
                research_question="Valid question",
                inclusion_criteria=["criteria"]
            )
        assert "Title cannot be empty" in str(exc.value)
        
    def test_review_addPaper_inSearchStage_addsSuccessfully(self):
        """test_review_addPaper_correctStage_paperAdded"""
        # Arrange
        review = self._create_valid_review()
        review.advance_stage()  # Move to SEARCH stage
        paper = self._create_test_paper()
        
        # Act
        review.add_paper(paper)
        
        # Assert
        assert len(review.papers) == 1
        assert paper in review.papers
        assert review.get_paper_count() == 1
        
    def test_review_addPaper_inPlanningStage_throwsWorkflowError(self):
        """test_review_addPaper_wrongStage_throwsWorkflowError"""
        # Arrange
        review = self._create_valid_review()
        paper = self._create_test_paper()
        
        # Act & Assert
        with pytest.raises(WorkflowError) as exc:
            review.add_paper(paper)
        assert "Cannot add papers in PLANNING stage" in str(exc.value)
        
    def test_review_addPaper_duplicate_ignoredSilently(self):
        """test_review_addPaper_duplicateDOI_noDuplicateStored"""
        # Arrange
        review = self._create_valid_review()
        review.advance_stage()
        paper1 = self._create_test_paper()
        paper2 = self._create_test_paper()  # Same DOI
        
        # Act
        review.add_paper(paper1)
        review.add_paper(paper2)
        
        # Assert
        assert len(review.papers) == 1
        
    def test_review_advanceStage_validTransition_updatesStage(self):
        """test_review_advanceStage_followsWorkflow_progressesCorrectly"""
        # Arrange
        review = self._create_valid_review()
        
        # Act & Assert
        assert review.stage == ReviewStage.PLANNING
        
        review.advance_stage()
        assert review.stage == ReviewStage.SEARCH
        
        review.advance_stage()
        assert review.stage == ReviewStage.SCREENING
        
        review.advance_stage()
        assert review.stage == ReviewStage.ANALYSIS
        
        review.advance_stage()
        assert review.stage == ReviewStage.SYNTHESIS
        
        review.advance_stage()
        assert review.stage == ReviewStage.COMPLETE
        
    def test_review_advanceStage_fromComplete_throwsWorkflowError(self):
        """test_review_advanceStage_alreadyComplete_throwsWorkflowError"""
        # Arrange
        review = self._create_valid_review()
        for _ in range(5):  # Advance to COMPLETE
            review.advance_stage()
            
        # Act & Assert
        with pytest.raises(WorkflowError) as exc:
            review.advance_stage()
        assert "Cannot advance from COMPLETE stage" in str(exc.value)
        
    def test_review_assessPaper_validAssessment_updatesQuality(self):
        """test_review_assessPaper_qualityScore_updatesSuccessfully"""
        # Arrange
        review = self._create_valid_review()
        review.advance_stage()  # SEARCH
        paper = self._create_test_paper()
        review.add_paper(paper)
        review.advance_stage()  # SCREENING
        
        # Act
        review.assess_paper(paper.doi, quality_score=8.5, include=True)
        
        # Assert
        assessment = review.paper_assessments[str(paper.doi)]
        assert assessment["quality_score"] == 8.5
        assert assessment["included"] is True
        assert paper.quality_score == 8.5
        
    def test_review_getIncludedPapers_filtersCorrectly(self):
        """test_review_getIncludedPapers_onlyIncluded_returnsFiltered"""
        # Arrange
        review = self._create_valid_review()
        review.advance_stage()  # SEARCH
        
        paper1 = self._create_test_paper("10.1234/paper1")
        paper2 = self._create_test_paper("10.1234/paper2")
        paper3 = self._create_test_paper("10.1234/paper3")
        
        for paper in [paper1, paper2, paper3]:
            review.add_paper(paper)
            
        review.advance_stage()  # SCREENING
        
        # Act
        review.assess_paper(paper1.doi, quality_score=9.0, include=True)
        review.assess_paper(paper2.doi, quality_score=4.0, include=False)
        review.assess_paper(paper3.doi, quality_score=7.5, include=True)
        
        included = review.get_included_papers()
        
        # Assert
        assert len(included) == 2
        assert paper1 in included
        assert paper3 in included
        assert paper2 not in included
        
    def test_review_generateStatistics_calculatesCorrectly(self):
        """test_review_generateStatistics_multiplesPapers_accurateStats"""
        # Arrange
        review = self._create_and_populate_review()
        
        # Act
        stats = review.generate_statistics()
        
        # Assert
        assert stats["total_papers"] == 3
        assert stats["included_papers"] == 2
        assert stats["excluded_papers"] == 1
        assert stats["inclusion_rate"] == 2/3
        assert stats["average_quality_score"] == 7.0  # (9+4+7.5)/3
        assert stats["stage"] == "SCREENING"
        
    def test_review_exportMetadata_includesAllFields(self):
        """test_review_exportMetadata_completeData_exportsAll"""
        # Arrange
        review = self._create_valid_review()
        review.add_keyword("machine learning")
        review.add_keyword("healthcare")
        
        # Act
        metadata = review.export_metadata()
        
        # Assert
        assert metadata["title"] == review.title
        assert metadata["research_question"] == review.research_question
        assert "machine learning" in metadata["keywords"]
        assert metadata["stage"] == "PLANNING"
        assert metadata["paper_count"] == 0
        
    # Helper methods
    def _create_valid_review(self) -> Review:
        """Factory for valid review"""
        return Review(
            title="Test Review",
            research_question="Test question?",
            inclusion_criteria=["peer-reviewed"],
            exclusion_criteria=["preprints"]
        )
        
    def _create_test_paper(self, doi: str = "10.1234/test") -> Paper:
        """Factory for test papers"""
        return Paper(
            doi=DOI(doi),
            title="Test Paper",
            authors=[Author("Test", "Author", "T")],
            publication_year=2023,
            journal="Test Journal"
        )
        
    def _create_and_populate_review(self) -> Review:
        """Create review with assessed papers"""
        review = self._create_valid_review()
        review.advance_stage()  # SEARCH
        
        papers = [
            self._create_test_paper("10.1234/paper1"),
            self._create_test_paper("10.1234/paper2"),
            self._create_test_paper("10.1234/paper3")
        ]
        
        for paper in papers:
            review.add_paper(paper)
            
        review.advance_stage()  # SCREENING
        
        review.assess_paper(papers[0].doi, quality_score=9.0, include=True)
        review.assess_paper(papers[1].doi, quality_score=4.0, include=False)
        review.assess_paper(papers[2].doi, quality_score=7.5, include=True)
        
        return review


class TestReviewPerformance:
    """Performance tests for Review operations"""
    
    def test_review_bulkAddPapers_1000papers_under100ms(self, benchmark):
        """test_review_bulkAdd_largeBatch_meetsPerformanceTarget"""
        # Arrange
        review = Review(
            title="Performance Test",
            research_question="Test?",
            inclusion_criteria=["test"]
        )
        review.advance_stage()  # SEARCH
        
        papers = [
            Paper(
                doi=DOI(f"10.1234/paper{i}"),
                title=f"Paper {i}",
                authors=[Author("Test", "Author", "T")],
                publication_year=2020,
                journal="Test"
            )
            for i in range(1000)
        ]
        
        # Act & Assert
        def bulk_add():
            for paper in papers:
                review.add_paper(paper)
                
        benchmark(bulk_add)
        assert len(review.papers) == 1000
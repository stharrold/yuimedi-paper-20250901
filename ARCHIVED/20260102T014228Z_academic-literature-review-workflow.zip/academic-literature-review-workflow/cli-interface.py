# interfaces/cli/review_cli.py
"""
Claude Code CLI for Academic Literature Review

Usage:
    claude-code review init
    claude-code review search [--database=<db>]
    claude-code review assess <doi>
    claude-code review analyze
    claude-code review synthesize
    claude-code review status
    claude-code review export [--format=<fmt>]
"""
import click
import json
import sys
from pathlib import Path
from typing import Optional, List, Dict, Any
from datetime import datetime

from domain.entities.review import Review, ReviewStage
from domain.entities.paper import Paper
from application.usecases.search_papers import SearchPapersUseCase
from application.usecases.analyze_themes import AnalyzeThemesUseCase
from application.usecases.generate_synthesis import GenerateSynthesisUseCase
from infrastructure.persistence.json_repository import JSONReviewRepository
from infrastructure.adapters.crossref_adapter import CrossrefAdapter


class ReviewCLI:
    """Main CLI controller for literature review workflow"""
    
    def __init__(self):
        self.repo = JSONReviewRepository("./review_data")
        self.current_review: Optional[Review] = None
        self._load_current_review()
        
    def _load_current_review(self) -> None:
        """Load active review if exists"""
        review_file = Path("./review_data/current_review.json")
        if review_file.exists():
            with open(review_file, 'r') as f:
                data = json.load(f)
                self.current_review = Review.from_dict(data)
                
    def _save_current_review(self) -> None:
        """Persist current review state"""
        if self.current_review:
            self.repo.save(self.current_review)
            

@click.group()
@click.pass_context
def cli(ctx):
    """Academic Literature Review Tool"""
    ctx.obj = ReviewCLI()


@cli.command()
@click.pass_obj
def init(cli_obj: ReviewCLI):
    """Initialize new literature review"""
    click.echo("🎯 Initializing new literature review...\n")
    
    # Collect review metadata
    title = click.prompt("Review title")
    research_question = click.prompt("Primary research question")
    
    # Sub-questions
    sub_questions = []
    click.echo("\n📋 Enter sub-questions (empty line to finish):")
    while True:
        sq = click.prompt("Sub-question", default="", show_default=False)
        if not sq:
            break
        sub_questions.append(sq)
        
    # Inclusion criteria
    inclusion = []
    click.echo("\n✅ Enter inclusion criteria (empty line to finish):")
    while True:
        inc = click.prompt("Inclusion", default="", show_default=False)
        if not inc:
            break
        inclusion.append(inc)
        
    # Exclusion criteria
    exclusion = []
    click.echo("\n❌ Enter exclusion criteria (empty line to finish):")
    while True:
        exc = click.prompt("Exclusion", default="", show_default=False)
        if not exc:
            break
        exclusion.append(exc)
        
    # Create review
    cli_obj.current_review = Review(
        title=title,
        research_question=research_question,
        inclusion_criteria=inclusion if inclusion else ["peer-reviewed"],
        exclusion_criteria=exclusion
    )
    
    # Add sub-questions as metadata
    cli_obj.current_review.sub_questions = sub_questions
    
    # Save
    cli_obj._save_current_review()
    
    click.echo(f"\n✅ Review initialized: {title}")
    click.echo(f"📁 Stage: {cli_obj.current_review.stage.value}")
    click.echo("\nNext: Run 'claude-code review search' to find papers")


@cli.command()
@click.option('--database', '-d', multiple=True, 
              help='Databases to search (crossref, pubmed, arxiv)')
@click.option('--keywords', '-k', help='Search keywords (comma-separated)')
@click.option('--limit', '-l', default=100, help='Max results per database')
@click.pass_obj
def search(cli_obj: ReviewCLI, database, keywords, limit):
    """Search for papers across databases"""
    if not cli_obj.current_review:
        click.echo("❌ No active review. Run 'review init' first.")
        sys.exit(1)
        
    # Advance to search stage if needed
    if cli_obj.current_review.stage == ReviewStage.PLANNING:
        cli_obj.current_review.advance_stage()
        
    click.echo(f"🔍 Searching for papers...\n")
    
    # Parse keywords
    if keywords:
        keyword_list = [k.strip() for k in keywords.split(',')]
    else:
        keyword_list = click.prompt(
            "Enter search keywords (comma-separated)"
        ).split(',')
        
    # Default databases
    if not database:
        database = ['crossref', 'pubmed']
        
    # Execute search
    search_use_case = SearchPapersUseCase(
        crossref=CrossrefAdapter() if 'crossref' in database else None,
        # Add other adapters as implemented
    )
    
    total_found = 0
    with click.progressbar(database, label='Searching databases') as dbs:
        for db in dbs:
            try:
                papers = search_use_case.execute(
                    query=' '.join(keyword_list),
                    database=db,
                    limit=limit
                )
                
                # Add to review
                for paper in papers:
                    cli_obj.current_review.add_paper(paper)
                    
                total_found += len(papers)
                
            except Exception as e:
                click.echo(f"\n⚠️  Error searching {db}: {e}")
                
    # Remove duplicates report
    unique_count = cli_obj.current_review.get_paper_count()
    duplicates = total_found - unique_count
    
    click.echo(f"\n📊 Search complete:")
    click.echo(f"   Total found: {total_found}")
    click.echo(f"   Duplicates removed: {duplicates}")
    click.echo(f"   Unique papers: {unique_count}")
    
    cli_obj._save_current_review()
    click.echo("\nNext: Run 'review assess <doi>' to evaluate papers")


@cli.command()
@click.argument('doi')
@click.pass_obj
def assess(cli_obj: ReviewCLI, doi):
    """Assess individual paper quality"""
    if not cli_obj.current_review:
        click.echo("❌ No active review.")
        sys.exit(1)
        
    # Find paper
    paper = next(
        (p for p in cli_obj.current_review.papers if str(p.doi) == doi),
        None
    )
    
    if not paper:
        click.echo(f"❌ Paper {doi} not found in review")
        sys.exit(1)
        
    # Display paper info
    click.echo(f"\n📄 {paper.title}")
    click.echo(f"👥 {', '.join(str(a) for a in paper.authors)}")
    click.echo(f"📅 {paper.publication_year} | 📖 {paper.journal}\n")
    
    if paper.abstract:
        click.echo("Abstract:")
        click.echo(click.wrap_text(paper.abstract, width=70))
        click.echo()
        
    # Quality assessment
    quality = click.prompt(
        "Quality score (0-10)",
        type=click.FloatRange(0, 10)
    )
    
    include = click.confirm("Include in review?")
    
    notes = click.prompt("Notes (optional)", default="", show_default=False)
    
    # Save assessment
    try:
        cli_obj.current_review.assess_paper(
            paper.doi,
            quality_score=quality,
            include=include,
            notes=notes
        )
        cli_obj._save_current_review()
        click.echo("✅ Assessment saved")
    except Exception as e:
        click.echo(f"❌ Error: {e}")


@cli.command()
@click.pass_obj
def analyze(cli_obj: ReviewCLI):
    """Analyze themes across included papers"""
    if not cli_obj.current_review:
        click.echo("❌ No active review.")
        sys.exit(1)
        
    # Advance stage if needed
    if cli_obj.current_review.stage == ReviewStage.SCREENING:
        cli_obj.current_review.advance_stage()
        
    included = cli_obj.current_review.get_included_papers()
    click.echo(f"\n🔬 Analyzing {len(included)} included papers...\n")
    
    # Run thematic analysis
    analyzer = AnalyzeThemesUseCase()
    themes = analyzer.execute(included)
    
    # Display results
    click.echo("📊 Key Themes Identified:\n")
    for theme in themes.themes:
        click.echo(f"• {theme.name} ({theme.paper_count} papers)")
        if theme.subthemes:
            for sub in theme.subthemes:
                click.echo(f"  - {sub}")
                
    click.echo(f"\n🔍 Research Gaps:")
    for gap in themes.gaps:
        click.echo(f"• {gap}")
        
    cli_obj._save_current_review()
    click.echo("\nNext: Run 'review synthesize' to generate synthesis")


@cli.command()
@click.pass_obj
def synthesize(cli_obj: ReviewCLI):
    """Generate narrative synthesis"""
    if not cli_obj.current_review:
        click.echo("❌ No active review.")
        sys.exit(1)
        
    if cli_obj.current_review.stage not in [ReviewStage.ANALYSIS, ReviewStage.SYNTHESIS]:
        click.echo("⚠️  Complete analysis first")
        sys.exit(1)
        
    click.echo("📝 Generating synthesis...\n")
    
    synthesizer = GenerateSynthesisUseCase()
    synthesis = synthesizer.execute(cli_obj.current_review)
    
    # Save to file
    output_file = Path(f"{cli_obj.current_review.title.lower().replace(' ', '_')}_synthesis.md")
    output_file.write_text(synthesis.content)
    
    click.echo(f"✅ Synthesis saved to: {output_file}")
    
    # Show preview
    click.echo("\n--- PREVIEW ---")
    lines = synthesis.content.split('\n')[:20]
    click.echo('\n'.join(lines))
    click.echo("\n[...continued in file]")


@cli.command()
@click.pass_obj  
def status(cli_obj: ReviewCLI):
    """Show current review status"""
    if not cli_obj.current_review:
        click.echo("❌ No active review")
        sys.exit(1)
        
    stats = cli_obj.current_review.generate_statistics()
    
    click.echo(f"\n📊 {cli_obj.current_review.title}")
    click.echo(f"{'='*50}")
    click.echo(f"Stage: {stats['stage']}")
    click.echo(f"Total papers: {stats['total_papers']}")
    click.echo(f"Assessed: {stats['assessed_papers']}")
    click.echo(f"Included: {stats['included_papers']}")
    click.echo(f"Excluded: {stats['excluded_papers']}")
    
    if stats['total_papers'] > 0:
        click.echo(f"Inclusion rate: {stats['inclusion_rate']:.1%}")
        
    if stats['average_quality_score'] > 0:
        click.echo(f"Avg quality: {stats['average_quality_score']:.1f}/10")
        
    click.echo(f"Days active: {stats['days_since_start']}")


@cli.command()
@click.option('--format', '-f', 
              type=click.Choice(['bibtex', 'json', 'docx', 'latex']),
              default='bibtex')
@click.pass_obj
def export(cli_obj: ReviewCLI, format):
    """Export review in various formats"""
    if not cli_obj.current_review:
        click.echo("❌ No active review")
        sys.exit(1)
        
    filename = f"{cli_obj.current_review.title.lower().replace(' ', '_')}.{format}"
    
    if format == 'json':
        with open(filename, 'w') as f:
            json.dump(cli_obj.current_review.to_dict(), f, indent=2)
    elif format == 'bibtex':
        # Export BibTeX
        from application.usecases.export_review import ExportReviewUseCase
        exporter = ExportReviewUseCase()
        content = exporter.export_bibtex(cli_obj.current_review)
        Path(filename).write_text(content)
    # Add other formats
    
    click.echo(f"✅ Exported to: {filename}")


if __name__ == '__main__':
    cli()
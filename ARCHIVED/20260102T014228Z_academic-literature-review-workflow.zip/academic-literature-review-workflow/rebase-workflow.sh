#!/bin/bash
# scripts/sync-branch.sh - Helper for frequent rebasing

# Daily sync workflow
git fetch origin
git checkout develop
git pull origin develop
git checkout -
git rebase develop

# Alternative: merge develop (preserves timeline)
# git merge develop --no-ff -m "Sync with develop"

# Set up automatic rebase reminder
# .git/hooks/post-checkout
#!/bin/sh
BRANCH=$(git rev-parse --abbrev-ref HEAD)
if [[ "$BRANCH" =~ ^[a-z]{2,3}/ ]]; then
    echo "⚠️  Remember to sync with develop: git rebase develop"
fi
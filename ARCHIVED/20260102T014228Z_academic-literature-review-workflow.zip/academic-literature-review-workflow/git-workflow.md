# Git Branch Management

## Branch Structure

```
main (v1.2.0)          # Production releases only
  └── develop          # Integration branch
       ├── jd/feature  # John Doe's feature
       ├── as/bugfix   # Alice Smith's bugfix
       └── bp/refactor # Bob Park's refactor
```

## Workflow

### 1. Start New Work
```bash
git checkout develop
git pull origin develop
git checkout -b jd/feature-name
```

### 2. Share Work (PR to develop)
```bash
git push origin jd/feature-name
# Create PR: jd/feature-name → develop
```

### 3. Release (PR develop → main)
```bash
git checkout develop
git pull origin develop
git checkout -b release/v1.2.0
# Create PR: release/v1.2.0 → main
```

## Rules

- **Never commit directly to main or develop**
- **All work starts from develop**
- **Feature branches: initials/description**
- **Tests must pass for all PRs**

## Protection Rules

```yaml
# GitHub branch protection
main:
  - Require PR reviews: 2
  - Require status checks: test
  - Dismiss stale reviews
  - No force pushes

develop:  
  - Require PR reviews: 1
  - Require status checks: test
```

## Result

- develop→main PRs trigger version tags (v1.0.0, v1.1.0, v1.2.0)
- Much cleaner tag history
- Clear release points
#!/bin/sh
# Pre-push hook - tests must pass

echo "Running tests before push..."
docker-compose run --rm test

if [ $? -ne 0 ]; then
    echo "Tests failed! Push aborted."
    exit 1
fi

echo "Tests passed!"
exit 0
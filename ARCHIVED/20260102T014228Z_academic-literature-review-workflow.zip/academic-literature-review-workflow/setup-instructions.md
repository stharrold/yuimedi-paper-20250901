# Literature Review Setup Guide for Claude Code

## Prerequisites

- Python 3.8+
- Claude Code CLI installed
- Git for version control

## Installation

### 1. Project Setup

```bash
# Create project directory
mkdir academic-review && cd academic-review

# Initialize git
git init

# Install uv if not already installed
curl -LsSf https://astral.sh/uv/install.sh | sh

# Create virtual environment with uv
uv venv
source .venv/bin/activate  # On Windows: .venv\Scripts\activate

# Create project structure
mkdir -p {domain/{entities,values,services},application/{usecases,ports},infrastructure/{adapters,persistence,ai},interfaces/{cli,api},tests}
```

### 2. Install Dependencies

Create `pyproject.toml`:
```toml
[project]
name = "academic-review"
version = "0.1.0"
requires-python = ">=3.8"
dependencies = [
    "click>=8.0.0",
    "requests>=2.28.0",
    "python-dotenv>=0.19.0",
    "bibtexparser>=1.4.0",
]

[project.optional-dependencies]
dev = [
    "pytest>=7.0.0",
    "pytest-benchmark>=3.4.1",
    "pytest-cov>=4.0.0",
    "flake8>=6.0.0",
    "mypy>=1.0.0",
    "black>=23.0.0",
    "isort>=5.12.0",
]
```

```bash
# Install all dependencies with uv
uv pip install -e ".[dev]"
```

### 3. Configure Claude Code

Create `.claude/settings.json`:
```json
{
  "permissions": {
    "allow": ["*"],
    "defaultMode": "acceptEdits"
  },
  "hooks": {
    "PostEdit": [{
      "matcher": "*.py",
      "hooks": [{
        "type": "command",
        "command": "python -m pytest tests/ -xvs"
      }]
    }]
  },
  "customCommands": {
    "/review": "python interfaces/cli/review_cli.py",
    "/test": "python -m pytest -xvs",
    "/coverage": "python -m pytest --cov=. --cov-report=html"
  }
}
```

### 4. Set Up Environment

Create `.env`:
```
# API Keys (optional)
CROSSREF_EMAIL=your-email@example.com
PUBMED_API_KEY=your-key-here
SEMANTIC_SCHOLAR_API_KEY=your-key-here

# Review settings
DEFAULT_DATABASE=crossref,pubmed
MAX_RESULTS_PER_DB=100
QUALITY_THRESHOLD=7.0
```

## Basic Workflow

### 1. Initialize Review

```bash
claude-code /review init
```

Follow prompts:
- Review title
- Research question
- Sub-questions
- Inclusion/exclusion criteria

### 2. Search Literature

```bash
# Basic search
claude-code /review search

# Targeted search
claude-code /review search --database=crossref --keywords="machine learning,healthcare" --limit=50
```

### 3. Assess Papers

```bash
# Check status first
claude-code /review status

# Assess individual papers
claude-code /review assess 10.1234/example.doi
```

### 4. Analyze Themes

```bash
claude-code /review analyze
```

### 5. Generate Synthesis

```bash
claude-code /review synthesize
```

### 6. Export Results

```bash
# Export formats
claude-code /review export --format=bibtex
claude-code /review export --format=json
claude-code /review export --format=docx
```

## Advanced Usage

### Custom Database Configuration

Create `config/databases.py`:
```python
DATABASES = {
    "crossref": {
        "adapter": "CrossrefAdapter",
        "config": {
            "email": "your-email@example.com",
            "rate_limit": 50
        }
    },
    "pubmed": {
        "adapter": "PubMedAdapter", 
        "config": {
            "api_key": "your-key",
            "batch_size": 100
        }
    }
}
```

### Batch Operations

```bash
# Bulk assess with CSV
claude-code /review assess-batch assessments.csv

# Import existing bibliography
claude-code /review import papers.bib
```

### Quality Control

```bash
# Run quality checks
claude-code /review qcheck

# Generate PRISMA diagram
claude-code /review prisma
```

### Collaboration

```bash
# Share review
claude-code /review share user@example.com

# Merge reviews
claude-code /review merge branch-name
```

## Claude Code Integration

### Custom Commands

Add to `.claude/settings.json`:
```json
{
  "customCommands": {
    "/find-gaps": "python -c \"from application.usecases.analyze_themes import find_research_gaps; find_research_gaps()\"",
    "/duplicate-check": "python -c \"from application.usecases.dedup import check_duplicates; check_duplicates()\"",
    "/citation-network": "python -c \"from application.usecases.citations import build_network; build_network()\""
  }
}
```

### Automated Workflows

Create `.claude/workflows/daily_review.yaml`:
```yaml
name: Daily Review
schedule: "0 9 * * *"
steps:
  - name: Update searches
    command: /review search --database=pubmed --limit=20
  - name: Check duplicates
    command: /duplicate-check
  - name: Generate report
    command: /review status > daily_report.txt
```

## Testing

### Run All Tests
```bash
claude-code /test
```

### Run Specific Tests
```bash
# Domain tests
pytest tests/domain/

# Use case tests  
pytest tests/application/

# Integration tests
pytest tests/integration/
```

### Coverage Report
```bash
claude-code /coverage
# View report at htmlcov/index.html
```

## Troubleshooting

### Common Issues

**Import errors:**
```bash
# Ensure PYTHONPATH includes project root
export PYTHONPATH="${PYTHONPATH}:$(pwd)"
```

**Database timeouts:**
```python
# Increase timeout in adapters
response = requests.get(url, timeout=60)
```

**Memory issues with large reviews:**
```bash
# Process in batches
claude-code /review search --limit=50
```

### Debug Mode

```bash
# Enable debug logging
export DEBUG=true
claude-code /review search
```

### Reset Review

```bash
# Backup current review
cp -r review_data review_data_backup

# Start fresh
rm -rf review_data/current_review.json
claude-code /review init
```

## Best Practices

1. **Commit regularly:** After each major step
2. **Document decisions:** Use assessment notes
3. **Verify data:** Run `/review qcheck` periodically
4. **Export backups:** Daily JSON exports
5. **Track metrics:** Monitor inclusion rates

## Quick Reference

| Command | Purpose |
|---------|---------|
| `/review init` | Start new review |
| `/review search` | Find papers |
| `/review assess <doi>` | Evaluate paper |
| `/review analyze` | Extract themes |
| `/review synthesize` | Generate narrative |
| `/review status` | Check progress |
| `/review export` | Save results |
| `/test` | Run tests |
| `/coverage` | Coverage report |
# domain/entities/review.py
from typing import List, Dict, Any, Optional, Set
from datetime import datetime
from enum import Enum
from dataclasses import dataclass, field

from domain.entities.paper import Paper
from domain.values.doi import DOI
from domain.exceptions import ValidationError, WorkflowError


class ReviewStage(Enum):
    """Literature review workflow stages"""
    PLANNING = "PLANNING"
    SEARCH = "SEARCH"
    SCREENING = "SCREENING"
    ANALYSIS = "ANALYSIS"
    SYNTHESIS = "SYNTHESIS"
    COMPLETE = "COMPLETE"


@dataclass
class Review:
    """
    Literature Review entity managing the review process.
    
    Enforces workflow rules and maintains review state.
    """
    title: str
    research_question: str
    inclusion_criteria: List[str]
    exclusion_criteria: List[str] = field(default_factory=list)
    papers: Set[Paper] = field(default_factory=set)
    keywords: List[str] = field(default_factory=list)
    stage: ReviewStage = ReviewStage.PLANNING
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    paper_assessments: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    
    def __post_init__(self):
        """Validate review data"""
        self._validate_title()
        self._validate_research_question()
        self._validate_criteria()
        
    def _validate_title(self) -> None:
        """Ensure title is not empty"""
        if not self.title or not self.title.strip():
            raise ValidationError("Title cannot be empty")
            
    def _validate_research_question(self) -> None:
        """Ensure research question is valid"""
        if not self.research_question or not self.research_question.strip():
            raise ValidationError("Research question cannot be empty")
            
    def _validate_criteria(self) -> None:
        """Ensure inclusion criteria exist"""
        if not self.inclusion_criteria:
            raise ValidationError("At least one inclusion criterion required")
            
    def add_paper(self, paper: Paper) -> None:
        """
        Add paper to review if in appropriate stage.
        
        Args:
            paper: Paper to add
            
        Raises:
            WorkflowError: If not in SEARCH or later stage
        """
        if self.stage == ReviewStage.PLANNING:
            raise WorkflowError("Cannot add papers in PLANNING stage")
            
        # Using set automatically prevents duplicates
        self.papers.add(paper)
        self.updated_at = datetime.now()
        
    def advance_stage(self) -> None:
        """
        Advance to next workflow stage.
        
        Raises:
            WorkflowError: If already complete
        """
        stage_order = list(ReviewStage)
        current_index = stage_order.index(self.stage)
        
        if current_index >= len(stage_order) - 1:
            raise WorkflowError("Cannot advance from COMPLETE stage")
            
        self.stage = stage_order[current_index + 1]
        self.updated_at = datetime.now()
        
    def assess_paper(
        self, 
        doi: DOI, 
        quality_score: float,
        include: bool,
        notes: str = ""
    ) -> None:
        """
        Assess paper quality and inclusion decision.
        
        Args:
            doi: Paper DOI
            quality_score: Quality score (0-10)
            include: Whether to include in final review
            notes: Assessment notes
            
        Raises:
            WorkflowError: If not in SCREENING stage or later
            ValidationError: If paper not in review
        """
        if self.stage not in [ReviewStage.SCREENING, ReviewStage.ANALYSIS, 
                              ReviewStage.SYNTHESIS, ReviewStage.COMPLETE]:
            raise WorkflowError(f"Cannot assess papers in {self.stage} stage")
            
        # Find paper by DOI
        paper = next((p for p in self.papers if p.doi == doi), None)
        if not paper:
            raise ValidationError(f"Paper with DOI {doi} not found in review")
            
        # Update paper quality score
        paper.set_quality_score(quality_score)
        
        # Store assessment
        self.paper_assessments[str(doi)] = {
            "quality_score": quality_score,
            "included": include,
            "notes": notes,
            "assessed_at": datetime.now()
        }
        self.updated_at = datetime.now()
        
    def get_included_papers(self) -> List[Paper]:
        """
        Get papers marked for inclusion.
        
        Returns:
            List of included papers
        """
        included_dois = {
            doi for doi, assessment in self.paper_assessments.items()
            if assessment.get("included", False)
        }
        
        return [
            paper for paper in self.papers
            if str(paper.doi) in included_dois
        ]
        
    def get_paper_count(self) -> int:
        """Get total paper count"""
        return len(self.papers)
        
    def add_keyword(self, keyword: str) -> None:
        """Add search keyword"""
        if keyword and keyword not in self.keywords:
            self.keywords.append(keyword)
            self.updated_at = datetime.now()
            
    def generate_statistics(self) -> Dict[str, Any]:
        """
        Generate review statistics.
        
        Returns:
            Dictionary with review metrics
        """
        total_papers = len(self.papers)
        assessed_papers = len(self.paper_assessments)
        included_papers = len([
            a for a in self.paper_assessments.values()
            if a.get("included", False)
        ])
        excluded_papers = assessed_papers - included_papers
        
        quality_scores = [
            paper.quality_score for paper in self.papers
            if paper.quality_score is not None
        ]
        avg_quality = sum(quality_scores) / len(quality_scores) if quality_scores else 0
        
        return {
            "total_papers": total_papers,
            "assessed_papers": assessed_papers,
            "included_papers": included_papers,
            "excluded_papers": excluded_papers,
            "inclusion_rate": included_papers / total_papers if total_papers > 0 else 0,
            "average_quality_score": avg_quality,
            "stage": self.stage.value,
            "days_since_start": (datetime.now() - self.created_at).days
        }
        
    def export_metadata(self) -> Dict[str, Any]:
        """
        Export review metadata.
        
        Returns:
            Dictionary with review metadata
        """
        return {
            "title": self.title,
            "research_question": self.research_question,
            "inclusion_criteria": self.inclusion_criteria,
            "exclusion_criteria": self.exclusion_criteria,
            "keywords": self.keywords,
            "stage": self.stage.value,
            "paper_count": len(self.papers),
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat()
        }
        
    def to_dict(self) -> Dict[str, Any]:
        """Serialize review to dictionary"""
        return {
            "metadata": self.export_metadata(),
            "papers": [paper.to_dict() for paper in self.papers],
            "assessments": self.paper_assessments,
            "statistics": self.generate_statistics()
        }
        
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Review':
        """Deserialize review from dictionary"""
        metadata = data["metadata"]
        review = cls(
            title=metadata["title"],
            research_question=metadata["research_question"],
            inclusion_criteria=metadata["inclusion_criteria"],
            exclusion_criteria=metadata.get("exclusion_criteria", []),
            keywords=metadata.get("keywords", []),
            stage=ReviewStage(metadata["stage"]),
            created_at=datetime.fromisoformat(metadata["created_at"]),
            updated_at=datetime.fromisoformat(metadata["updated_at"])
        )
        
        # Restore papers
        for paper_data in data.get("papers", []):
            paper = Paper.from_dict(paper_data)
            review.papers.add(paper)
            
        # Restore assessments
        review.paper_assessments = data.get("assessments", {})
        
        return review


# domain/exceptions.py
class WorkflowError(Exception):
    """Workflow validation error"""
    pass
# application/usecases/search_papers.py
from typing import List, Optional, Dict, Any
from dataclasses import dataclass
import asyncio
from concurrent.futures import ThreadPoolExecutor

from domain.entities.paper import Paper
from application.ports.search_service import SearchService


@dataclass
class SearchPapersUseCase:
    """
    Orchestrates paper search across multiple databases.
    
    Implements parallel search with deduplication.
    """
    crossref: Optional[SearchService] = None
    pubmed: Optional[SearchService] = None
    arxiv: Optional[SearchService] = None
    semantic_scholar: Optional[SearchService] = None
    
    def execute(
        self, 
        query: str, 
        database: Optional[str] = None,
        limit: int = 100
    ) -> List[Paper]:
        """
        Execute search on specified database(s).
        
        Args:
            query: Search query string
            database: Specific database or None for all
            limit: Max results per database
            
        Returns:
            List of unique papers
        """
        if database:
            return self._search_single(database, query, limit)
        else:
            return self._search_all(query, limit)
            
    def _search_single(
        self, 
        database: str, 
        query: str, 
        limit: int
    ) -> List[Paper]:
        """Search single database"""
        adapter = self._get_adapter(database)
        if not adapter:
            raise ValueError(f"Database {database} not configured")
            
        return adapter.search(query, limit)
        
    def _search_all(self, query: str, limit: int) -> List[Paper]:
        """Search all configured databases in parallel"""
        adapters = self._get_all_adapters()
        
        # Parallel search using thread pool
        with ThreadPoolExecutor(max_workers=len(adapters)) as executor:
            futures = [
                executor.submit(adapter.search, query, limit)
                for adapter in adapters.values()
            ]
            
            all_papers = []
            for future in futures:
                try:
                    papers = future.result(timeout=30)
                    all_papers.extend(papers)
                except Exception as e:
                    # Log but don't fail entire search
                    print(f"Search error: {e}")
                    
        # Deduplicate by DOI
        unique_papers = {}
        for paper in all_papers:
            if str(paper.doi) not in unique_papers:
                unique_papers[str(paper.doi)] = paper
                
        return list(unique_papers.values())
        
    def _get_adapter(self, database: str) -> Optional[SearchService]:
        """Get adapter for database"""
        return {
            'crossref': self.crossref,
            'pubmed': self.pubmed,
            'arxiv': self.arxiv,
            'semantic_scholar': self.semantic_scholar
        }.get(database.lower())
        
    def _get_all_adapters(self) -> Dict[str, SearchService]:
        """Get all configured adapters"""
        adapters = {}
        if self.crossref:
            adapters['crossref'] = self.crossref
        if self.pubmed:
            adapters['pubmed'] = self.pubmed
        if self.arxiv:
            adapters['arxiv'] = self.arxiv
        if self.semantic_scholar:
            adapters['semantic_scholar'] = self.semantic_scholar
        return adapters


# application/ports/search_service.py
from abc import ABC, abstractmethod
from typing import List

from domain.entities.paper import Paper


class SearchService(ABC):
    """Port for paper search services"""
    
    @abstractmethod
    def search(self, query: str, limit: int = 100) -> List[Paper]:
        """Search for papers matching query"""
        pass


# infrastructure/adapters/crossref_adapter.py
import requests
from typing import List, Dict, Any
from datetime import datetime

from domain.entities.paper import Paper
from domain.values.doi import DOI
from domain.values.author import Author
from application.ports.search_service import SearchService


class CrossrefAdapter(SearchService):
    """Crossref API adapter for paper search"""
    
    BASE_URL = "https://api.crossref.org/works"
    
    def search(self, query: str, limit: int = 100) -> List[Paper]:
        """
        Search Crossref for papers.
        
        Args:
            query: Search query
            limit: Maximum results
            
        Returns:
            List of Paper entities
        """
        params = {
            'query': query,
            'rows': min(limit, 1000),  # Crossref max
            'select': 'DOI,title,author,published-print,container-title,abstract',
            'sort': 'relevance',
            'order': 'desc'
        }
        
        try:
            response = requests.get(
                self.BASE_URL,
                params=params,
                timeout=30,
                headers={'User-Agent': 'LiteratureReviewTool/1.0'}
            )
            response.raise_for_status()
            
            data = response.json()
            items = data.get('message', {}).get('items', [])
            
            papers = []
            for item in items:
                paper = self._parse_crossref_item(item)
                if paper:
                    papers.append(paper)
                    
            return papers[:limit]
            
        except Exception as e:
            raise RuntimeError(f"Crossref search failed: {e}")
            
    def _parse_crossref_item(self, item: Dict[str, Any]) -> Optional[Paper]:
        """Parse Crossref API item to Paper entity"""
        try:
            # Extract required fields
            doi_str = item.get('DOI')
            if not doi_str:
                return None
                
            title = item.get('title', [''])[0]
            if not title:
                return None
                
            # Parse authors
            authors = []
            for author_data in item.get('author', []):
                author = self._parse_author(author_data)
                if author:
                    authors.append(author)
                    
            if not authors:
                return None
                
            # Parse year
            date_parts = item.get('published-print', {}).get('date-parts', [[]])
            if date_parts and date_parts[0]:
                year = date_parts[0][0]
            else:
                # Fallback to online date
                date_parts = item.get('published-online', {}).get('date-parts', [[]])
                year = date_parts[0][0] if date_parts and date_parts[0] else datetime.now().year
                
            # Journal
            journal = item.get('container-title', [''])[0] or "Unknown"
            
            # Abstract
            abstract = item.get('abstract', '')
            
            return Paper(
                doi=DOI(doi_str),
                title=title,
                authors=authors,
                publication_year=year,
                journal=journal,
                abstract=abstract
            )
            
        except Exception:
            return None
            
    def _parse_author(self, author_data: Dict[str, Any]) -> Optional[Author]:
        """Parse author from Crossref format"""
        try:
            last_name = author_data.get('family', '')
            first_name = author_data.get('given', '')
            
            if not last_name:
                return None
                
            # Generate initials from first name
            initials = ''.join([n[0].upper() for n in first_name.split() if n])
            
            return Author(
                last_name=last_name,
                first_name=first_name or "Unknown",
                initials=initials or last_name[0].upper(),
                orcid=author_data.get('ORCID')
            )
        except Exception:
            return None
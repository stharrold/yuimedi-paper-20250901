# Docker Development Workflow

## Quick Start

```bash
# Development mode
docker-compose run --rm dev
# Inside container:
make init
make search

# Run tests
docker-compose run --rm test

# Deploy
git push origin main  # Auto-builds & pushes to Docker Hub
```

## Concerns & Recommendations

### 1. **No Port 8080 Needed**
This is a CLI tool, not web app. Removed port mapping.

### 2. **Secrets Management**
```yaml
# docker-compose.override.yml (gitignored)
services:
  dev:
    env_file:
      - secrets.env
```

### 3. **Hot Reload Works**
Volume mount enables instant code updates. For Python imports:
```python
# Add to .env for development
PYTHONDONTWRITEBYTECODE=1
```

### 4. **Test Before Push**
```bash
# Pre-push hook (.git/hooks/pre-push)
#!/bin/sh
docker-compose run --rm test || exit 1
```

### 5. **Production vs Dev**
- Dev: Mounts local code, includes dev tools
- Prod: Copies code, minimal image

### 6. **Data Persistence**
Review data in Docker volume survives container restarts.

## Production Usage

```bash
docker run -it --rm \
  -v $(pwd)/review_data:/opt/data/my-repo/review_data \
  -v $(pwd)/.env:/opt/data/my-repo/.env:ro \
  your-dockerhub/academic-review:latest \
  academic-review search --keywords="your,terms"
```

## CI/CD Pipeline

1. PR → Run tests in container
2. Merge to main → Build & push to Docker Hub
3. Tagged releases → Version-specific images

Your workflow is solid. Main adjustment: this is CLI-focused, not web-based.
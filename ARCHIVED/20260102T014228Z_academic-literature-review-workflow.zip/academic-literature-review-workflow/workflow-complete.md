# Complete Development Workflow

## Stage 0→1: Feature Development

```bash
# Start feature
git checkout develop
git pull origin develop
git checkout -b jd/new-feature

# Daily workflow
./scripts/sync.sh                    # Rebase onto develop
edit > save > git commit -m "Add X"
git push                             # Pre-push hook runs tests

# Continue until feature complete
```

## Stage 1→2: Integration (PR to develop)

```bash
# Final checks before PR
make pr-check                        # Docker build with cache + tests
make pr-develop                      # Create PR to develop

# GitHub Actions runs:
# - Docker build WITH cache (fast)
# - All tests must pass
# - Code review required
```

## Stage 2→3: Release (PR to main)

```bash
# From develop branch
git checkout develop
git pull origin develop
make pr-check                        # Final validation
make pr-main                         # Create release PR

# GitHub Actions runs:
# - Docker build WITHOUT cache (clean)
# - All tests must pass
# - 2 reviewers required
# - Auto-creates version tag on merge
# - Pushes to Docker Hub
```

## Commands Reference

| Command | Purpose | Cache |
|---------|---------|-------|
| `make test` | Local unit tests | N/A |
| `make pr-check` | Pre-PR validation | Yes |
| `./scripts/sync.sh` | Sync with develop | N/A |
| Push to develop | Integration test | Yes |
| Push to main | Release build | No |

## Setup

```bash
# Enable sync script
chmod +x scripts/sync.sh

# Install pre-push hook
chmod +x .git/hooks/pre-push

# Install GitHub CLI for PR creation
brew install gh
gh auth login
```
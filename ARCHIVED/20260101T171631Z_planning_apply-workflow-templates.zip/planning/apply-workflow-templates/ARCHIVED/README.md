---
type: directory-documentation
directory: planning/apply-workflow-templates/ARCHIVED
title: Archived - Apply Workflow Templates
sibling_claude: CLAUDE.md
parent: ../README.md
children: []
---

# Archived - Apply Workflow Templates

Archived/deprecated files from the apply-workflow-templates feature planning.

## Contents

No archived files yet.

---
type: claude-context
directory: planning/apply-workflow-templates/ARCHIVED
purpose: Archived files for apply-workflow-templates feature
parent: ../CLAUDE.md
sibling_readme: README.md
children: []
---

# Claude Code Context: ARCHIVED

## Purpose

Archived/deprecated files from the apply-workflow-templates feature planning.

## Contents

Empty - no archived files yet.

"""Git Workflow Manager skill scripts package."""

__version__ = "5.0.0"

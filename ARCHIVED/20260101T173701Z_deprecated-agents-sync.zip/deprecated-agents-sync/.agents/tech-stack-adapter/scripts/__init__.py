# SPDX-FileCopyrightText: 2025 Yuimedi Corp.
# SPDX-License-Identifier: Apache-2.0
"""Tech Stack Adapter skill scripts package."""

__version__ = "5.0.0"

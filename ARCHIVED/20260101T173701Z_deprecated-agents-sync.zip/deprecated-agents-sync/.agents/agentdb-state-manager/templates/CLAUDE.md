---
type: claude-context
directory: .claude/skills/agentdb-state-manager/templates
purpose: Markdown and code templates for this skill.
parent: ../CLAUDE.md
sibling_readme: null
children:
  []
---

# Claude Code Context: templates

## Purpose

Markdown and code templates for this skill.

## Contents

- `workflow-states.json` - Configuration

## Related

- **Parent**: [agentdb-state-manager](../CLAUDE.md)

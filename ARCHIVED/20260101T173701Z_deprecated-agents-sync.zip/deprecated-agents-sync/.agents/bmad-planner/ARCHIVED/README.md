---
type: directory-documentation
directory: .claude/skills/bmad-planner/ARCHIVED
title: Archived Files
sibling_claude: CLAUDE.md
parent: ../README.md
children: []
---

# Archived Files

## Overview

Archive of deprecated files that are no longer in active use.

## Contents

[Describe the contents of this directory]

## Structure

[Explain the organization and key files]

## Usage

[How to use the resources in this directory]

## Related Documentation

- **[CLAUDE.md](CLAUDE.md)** - Context for Claude Code
- **[../README.md](../README.md)** - Parent directory documentation

---
type: claude-context
directory: specs/workflow-test-coverage/ARCHIVED
purpose: Archived specifications and deprecated files
parent: ../CLAUDE.md
children: []
---

# Claude Code Context: specs/workflow-test-coverage/ARCHIVED

Archived specifications and deprecated files.

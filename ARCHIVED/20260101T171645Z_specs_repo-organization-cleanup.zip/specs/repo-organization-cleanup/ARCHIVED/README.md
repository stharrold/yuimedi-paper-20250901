# Archived: specs/repo-organization-cleanup

Deprecated specification files are stored here.

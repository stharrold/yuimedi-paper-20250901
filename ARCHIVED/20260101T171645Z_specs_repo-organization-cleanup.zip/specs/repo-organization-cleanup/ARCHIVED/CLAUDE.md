---
type: claude-context
directory: specs/repo-organization-cleanup/ARCHIVED
purpose: Archived specifications and deprecated files
parent: ../CLAUDE.md
sibling_readme: null
children: []
---

# Claude Code Context: specs/repo-organization-cleanup/ARCHIVED

Archived specifications and deprecated files.

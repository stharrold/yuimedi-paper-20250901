# Archived Planning Documents

## Overview

Archive of deprecated planning documents that are no longer in active use.

## Contents

This directory contains archived versions of requirements.md, architecture.md, and epics.md that have been replaced or superseded.

---
type: claude-context
directory: specs/fix-paper-references/ARCHIVED
purpose: Archived specifications for fix-paper-references feature
parent: ../CLAUDE.md
sibling_readme: null
children: []
related_skills: []
---

# Claude Code Context: specs/fix-paper-references/ARCHIVED

Archived specifications and deprecated files.

# Archived: specs/fix-paper-references

Deprecated specification files are stored here.

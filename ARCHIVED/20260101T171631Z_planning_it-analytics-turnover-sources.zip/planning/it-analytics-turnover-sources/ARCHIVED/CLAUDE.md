---
type: claude-context
directory: planning/it-analytics-turnover-sources/ARCHIVED
purpose: Archive for deprecated planning documents
parent: planning/it-analytics-turnover-sources/CLAUDE.md
sibling_readme: README.md
children: []
---

# Claude Code Context: ARCHIVED

## Purpose

Archive for deprecated planning documents.

## Contents

Currently empty - no archived documents yet.

## Related

- **Parent:** [it-analytics-turnover-sources](../CLAUDE.md)

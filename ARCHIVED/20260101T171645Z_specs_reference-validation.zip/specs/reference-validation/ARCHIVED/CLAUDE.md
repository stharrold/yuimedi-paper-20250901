---
type: claude-context
directory: specs/reference-validation/ARCHIVED
purpose: Archived specifications and deprecated files
parent: ../CLAUDE.md
sibling_readme: null
children: []
related_skills: []
---

# Claude Code Context: specs/reference-validation/ARCHIVED

Archived specifications and deprecated files.

# Archived: specs/reference-validation

Deprecated specification files are stored here.
